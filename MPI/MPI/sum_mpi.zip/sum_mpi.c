//mpicc exec.c -o exec

//mpirun -machinefile maquinas.in -np NUMEROPROCESSOS a.out

#include <mpi.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv){
    int rank, token = 0, size;
    int tag=0;
    MPI_Status status;
    int matrix[10][30];
    int resp;
    int result = 0;
    int matrix_receive[30];

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if(rank == 0) {
        resp = 0;
        for(int i = 0; i< 10; i++){
          for(int j = 0; j< 30; j++){
            matrix[i][j] = 0;
          }
        }
        for(int i = 0; i<2; i++){
          //rank++;
          MPI_Send(&(matrix[0][0]),300,MPI_INT,i+1,tag,MPI_COMM_WORLD); //Envia matriz
          MPI_Send(&i,1,MPI_INT,i+1,tag,MPI_COMM_WORLD); // Envia trecho
        }
        for(int i = 0; i<2; i++){
          MPI_Recv(&resp,1,MPI_INT,MPI_ANY_SOURCE,tag,MPI_COMM_WORLD,&status);
          result += resp;
        }
        printf("RESULTADO: %d\n", result);
    }
    else{
        int r;
        MPI_Recv(&(matrix[0][0]),300,MPI_INT,0,tag,MPI_COMM_WORLD,&status); //Recebe matriz
        MPI_Recv(&r,1,MPI_INT,0,tag,MPI_COMM_WORLD,&status); //Recebe trecho

        for(int i = r*rank-1; i<30*rank; i++){
          resp = resp + matrix_receive[i];
        }

        MPI_Send(&resp, 1, MPI_INT, 0, tag, MPI_COMM_WORLD);
    }

    MPI_Finalize();
    return 0;
}
